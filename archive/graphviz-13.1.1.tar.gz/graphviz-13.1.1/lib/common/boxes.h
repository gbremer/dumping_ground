/// @file
/// @ingroup common_utils
#pragma once

#include <common/geom.h>
#include <util/list.h>

DEFINE_LIST(boxes, boxf)
