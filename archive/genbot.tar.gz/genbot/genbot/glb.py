
from __future__ import absolute_import, division, print_function
# these are the known steps that have been defined
known_steps = {}
known_environments = {}
known_schedulers = {}
known_reporters = {}
known_cs = {}

defined_pipeline = {}

