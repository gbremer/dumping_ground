#pragma once

/// @return 0 on success
int stress_model(int dim, SparseMatrix D, double **x, int maxit);
